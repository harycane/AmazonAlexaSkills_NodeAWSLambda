// Alexa SDK for JavaScript v1.0.00
// Copyright (c) 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved. Use is subject to license terms.

/**
 * Twitter API Keys
 **/
var TWITTER_CONFIG = {
        "consumerKey": "O4eL312uS6IfCS8fwD8jIeIlJ",
        "consumerSecret": "GSoun3Ikh43Lt3pMFwlPK0fm7nuhd1bQSKqZJU3FWi2HljER4s",
        "accessToken": "126565354-ZiX6AqFbbcBYOwSzlJYZ3CYWROQtd179eYM2JiQ6",
        "accessTokenSecret": "DkK63lVe5FYm7cf4oD9cQYl30OJq504jM4xq7LTORGt3V"
        //"callBackUrl": "XXX"
    }, twitterClient = null;
/**
 * The AlexaSkill prototype and helper functions
 */
var AlexaSkill = require('./AlexaSkill');

/**
 * Use the aws-lib
 */
var aws = require("aws-lib");

/**
 * Use the Twitter library
 */
var Twitter = require("twitter-node-client").Twitter;


/**
 * TwitterSkill is a child of AlexaSkill.
 * To read more about inheritance in JavaScript, see the link below.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Introduction_to_Object-Oriented_JavaScript#Inheritance
 */
 var APP_ID = 'amzn1.ask.skill.d79fd71f-95a5-4df4-bd05-8be99c6e90c3';

var TwitterSkill = function () {
    AlexaSkill.call(this, APP_ID);
};

// Extend AlexaSkill
TwitterSkill.prototype = Object.create(AlexaSkill.prototype);
TwitterSkill.prototype.constructor = TwitterSkill;

TwitterSkill.prototype.eventHandlers.onSessionStarted = function (sessionStartedRequest, session) {
    console.log("TwitterSkill onSessionStarted requestId: " + sessionStartedRequest.requestId
        + ", sessionId: " + session.sessionId);
    twitterClient = new Twitter(TWITTER_CONFIG);

    // any session init logic would go here
};

TwitterSkill.prototype.eventHandlers.onLaunch = function (launchRequest, session, response) {
    console.log("TwitterSkill onLaunch requestId: " + launchRequest.requestId + ", sessionId: " + session.sessionId);
    getTrends(response);
};

TwitterSkill.prototype.eventHandlers.onSessionEnded = function (sessionEndedRequest, session) {
    console.log("TwitterSkill onSessionEnded requestId: " + sessionEndedRequest.requestId
        + ", sessionId: " + session.sessionId);
    // any session cleanup logic would go here
};

TwitterSkill.prototype.intentHandlers = {
    Trends: function (intent, session, response) {
        getTrends(intent, session, response);
    },
};
/**
 * Returns the welcome response for when a user invokes this skill.
 */

function getTrends(response) {
    var trendString = "Here are the top trendng topics in your Area.";
    //get a
    twitterClient.getCustomApiCall('/trends/place.json',{"id":23511745},
        function (err,response,body) {
            trendString = "There was an error.";
        },
        function (data) {
            data = JSON.parse(data);
            //trendString = data[0].trends[0].name;
            for(var i = 0; i< 9; i++) {
                trendString = trendString +", "+ data[0].trends[i].name;
            }
        response.tell(trendString);
        }
    );

}

// Create the handler that responds to the Alexa Request.
exports.handler = function (event, context) {
    var twitterSkill = new TwitterSkill();
    twitterSkill.execute(event, context);
};
